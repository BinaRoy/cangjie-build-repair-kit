#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")" && pwd)/../knowledge/external"
mkdir -p "$BASE_DIR"
repos=(
  "https://gitcode.com/Cangjie/cangjie_tools.git"
  "https://gitcode.com/Cangjie/cangjie_compiler.git"
  "https://gitcode.com/Cangjie/cangjie_runtime.git"
  "https://gitcode.com/Cangjie/cangjie_docs.git"
)
for repo in "${repos[@]}"; do
  name="$(basename "$repo" .git)"
  dst="$BASE_DIR/$name"
  if [ -d "$dst" ]; then
    echo "skip $name (exists)"
    continue
  fi
  git clone "$repo" "$dst"
done
echo "knowledge bootstrap completed."
