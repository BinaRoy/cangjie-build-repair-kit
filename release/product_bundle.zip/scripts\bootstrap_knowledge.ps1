$ErrorActionPreference = 'Stop'
$base = Join-Path $PSScriptRoot '..\knowledge\external'
New-Item -ItemType Directory -Force -Path $base | Out-Null
$repos = @(
  'https://gitcode.com/Cangjie/cangjie_tools.git',
  'https://gitcode.com/Cangjie/cangjie_compiler.git',
  'https://gitcode.com/Cangjie/cangjie_runtime.git',
  'https://gitcode.com/Cangjie/cangjie_docs.git'
)
foreach ($repo in $repos) {
  $name = [System.IO.Path]::GetFileNameWithoutExtension($repo)
  $dst = Join-Path $base $name
  if (Test-Path $dst) { Write-Host "skip $name (exists)"; continue }
  git clone $repo $dst
}
Write-Host 'knowledge bootstrap completed.'
