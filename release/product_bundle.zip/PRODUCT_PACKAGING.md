# Product Packaging Notes

## Included
- Core engine: driver/adapters/repair
- Config templates: configs/
- Lightweight knowledge and lookup rules: knowledge/ (excluding external mirrors)
- CLI entry and docs
- Minimal examples

## Excluded
- Runtime artifacts: runs/, logs/
- IDE/cache folders
- External mirrored repos under knowledge/external/

## Restore external knowledge
- PowerShell: `scripts/bootstrap_knowledge.ps1`
- Bash: `scripts/bootstrap_knowledge.sh`
